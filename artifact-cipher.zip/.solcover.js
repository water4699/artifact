module.exports = {
  istanbulReporter: ["html", "lcov"],
  skipFiles: ["test"],
};
