
/*
  This file is auto-generated.
  Command: 'npm run genabi'
*/
export const EncryptedArtifactVotingAddresses = { 
  "11155111": { address: "0xd0703851f993c86e5683a6dCFE5fc7ef8E9e4431", chainId: 11155111, chainName: "sepolia" },
  "31337": { address: "0x5FbDB2315678afecb367f032d93F642f64180aa3", chainId: 31337, chainName: "hardhat" },
};
