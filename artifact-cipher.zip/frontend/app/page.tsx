import { ArtifactVotingApp } from "../src/components/ArtifactVotingApp";

export default function Home() {
  return (
    <main style={{ position: 'relative', zIndex: 1, width: '100%' }}>
      <ArtifactVotingApp />
    </main>
  );
}
